How to run the game:-
(Important note:- the code will not run directly due to browser hosting issues use VS-code instead)

step-1:-After Unzipping the Folder, open the folder "MemoryCardGame" with Visual Studio Code.
(note:- if you don't have visual studio install using this link https://code.visualstudio.com/)

step-2:-when the folder opens in visual studio code, Right-click on index.html file present in Explorer-menu.

step-3:-then choose "open with Live-Server" option or click on the "Go-live" option present at bottom-right corner in VS code bottom-tab
(note:-you should have installed extension of Live-server in VS-code to run the project)
After that you will see it takes you to the browser and now can paly the game 